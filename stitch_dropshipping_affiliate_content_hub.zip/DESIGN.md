---
name: High-Velocity Affiliate Hub
colors:
  surface: '#f7f9fc'
  surface-dim: '#d8dadd'
  surface-bright: '#f7f9fc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f7'
  surface-container: '#eceef1'
  surface-container-high: '#e6e8eb'
  surface-container-highest: '#e0e3e6'
  on-surface: '#191c1e'
  on-surface-variant: '#3c4a3c'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f4'
  outline: '#6c7b6a'
  outline-variant: '#bbcbb8'
  surface-tint: '#006e2a'
  primary: '#006e2a'
  on-primary: '#ffffff'
  primary-container: '#00c853'
  on-primary-container: '#004c1b'
  inverse-primary: '#3ce36a'
  secondary: '#525f75'
  on-secondary: '#ffffff'
  secondary-container: '#d6e3fe'
  on-secondary-container: '#58657b'
  tertiary: '#426086'
  on-tertiary: '#ffffff'
  tertiary-container: '#91afd9'
  on-tertiary-container: '#234266'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#69ff87'
  primary-fixed-dim: '#3ce36a'
  on-primary-fixed: '#002108'
  on-primary-fixed-variant: '#00531e'
  secondary-fixed: '#d6e3fe'
  secondary-fixed-dim: '#bac7e1'
  on-secondary-fixed: '#0e1c2f'
  on-secondary-fixed-variant: '#3a475c'
  tertiary-fixed: '#d3e4ff'
  tertiary-fixed-dim: '#aac9f4'
  on-tertiary-fixed: '#001c38'
  on-tertiary-fixed-variant: '#29486d'
  background: '#f7f9fc'
  on-background: '#191c1e'
  surface-variant: '#e0e3e6'
  brand-emerald-deep: '#046A38'
  surface-card: '#FFFFFF'
  border-subtle: '#E2E8F0'
  border-strong: '#CBD5E1'
  text-primary: '#0B192C'
  text-muted: '#60687A'
  rating-gold: '#F59E0B'
  disclosure-bg: '#F8FAFC'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  metric-display:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 32px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system is tailored for an authoritative, high-converting B2B/e-commerce affiliate platform reviewing dropshipping software and SEO intelligence suites. The brand persona blends technical precision, transparency, and data-backed authority. It avoids gimmicky affiliate tropes in favor of an institutional software intelligence portal, evoking trust, speed, and analytical rigor.

The visual style is **Corporate / Modern** augmented with **High-Contrast Precision**:
- Razor-sharp structural cards set against high-clarity neutral surfaces.
- Deep maritime navies communicating stability, contrasted with high-energy emerald CTA cues designed to drive conversion pathways.
- Editorial data architecture: clear visual anchoring through micro-badges, comparison matrix grids, and distinct affiliate disclosures.

## Colors

The palette balances authoritative deep navy structures with an energetic emerald primary system calibrated for maximum conversion affordance.

- **Primary (`#00C853`)**: The conversion engine. Reserved exclusively for high-intent actions—affiliate outbound clicks, key comparison CTAs, and top-tier score indicators. Paired with `brand-emerald-deep` (`#046A38`) for hover states and borders to guarantee accessible text contrast.
- **Secondary (`#0B192C`)**: Anchor navy. Serves as the primary typography baseline, authoritative table headers, navigation containers, and prominent badges.
- **Tertiary (`#1E3E62`)**: Mid-tone slate navy. Deployed for secondary controls, metric table borders, inactive states, and interactive tabs.
- **Neutral (`#F5F7FA`)**: Crisp slate-white canvas providing strong contrast separation behind `#FFFFFF` product review cards and comparison matrices.
- **Functional Semantics**: `rating-gold` (`#F59E0B`) highlights editorial ratings, while `disclosure-bg` (`#F8FAFC`) anchors legal compliance banners.

## Typography

The typography system pairs **Plus Jakarta Sans** for headlines and high-value data points with **Inter** for dense transactional UI, tabular readouts, and long-form reviews.

- **Headlines (Plus Jakarta Sans)**: Carries geometric energy and approachable precision. Tighter tracking (`-0.02em` to `-0.01em`) maintains density across comparison banners and hero value props.
- **Body & Controls (Inter)**: High x-height, neutral tone, and unmatched legibility in complex data matrices. Standardized at 15px/24px for body prose to balance scanning speed with high information retention.
- **Micro-labels**: Rendered in uppercase 11px bold Inter with expanded tracking (`0.05em`) for category flags, affiliate disclaimers, and table column headers.

## Layout & Spacing

The layout is built upon an 8pt-derived spacing rhythm within a 12-column responsive fluid grid capped at `1280px` max content width for reading hubs, and `1440px` for wide multi-tool comparison matrices.

- **Breakpoints**: Mobile (< 768px), Tablet (768px - 1024px), Desktop (> 1024px).
- **Margins & Gutters**: Mobile layouts collapse to 16px outer margins with 12px gutters to maximize horizontal space for tables and cards. Desktop interfaces expand to 32px canvas margins with 24px column gutters.
- **Density**: Affiliate product cards use strict internal spacing (`space-md` on mobile, `space-lg` on desktop) to anchor the headline, rating badge, feature checklist, and CTA without cognitive bloat.

## Elevation & Depth

This design system avoids heavy shadows, instead relying on **low-contrast outlines** coupled with subtle, high-spread ambient drop shadows to communicate layer priority:

- **Flat / Base**: `#FFFFFF` cards sit directly on the `#F5F7FA` neutral background bounded by crisp 1px borders (`#E2E8F0`).
- **Card Rest**: `box-shadow: 0 1px 3px rgba(11, 25, 44, 0.04), 0 1px 2px rgba(11, 25, 44, 0.02)`.
- **Interactive Hover / Featured Winner**: `box-shadow: 0 12px 24px -6px rgba(11, 25, 44, 0.08), 0 4px 8px -4px rgba(11, 25, 44, 0.04)`, combined with a border transition to `#1E3E62` or `#00C853` for the #1 ranked platform.
- **Sticky Affordance (Floating CTAs & Headers)**: `box-shadow: 0 4px 20px rgba(11, 25, 44, 0.08)` over a blurred white backdrop (`backdrop-filter: blur(8px)`).

## Shapes

The interface adopts a **Rounded** (Level 2) shape language:
- Buttons, inputs, and category chips utilize standard `0.5rem` (8px) corner radii, projecting modern software professionalism.
- Review cards, software comparison containers, and disclosure callouts feature `1rem` (16px) radii (`rounded-lg`), providing soft enclosing boundaries around high-density technical copy.
- Rating badges and micro-pills use full circular treatments (`9999px`) to distinguish categorical metadata from actionable rectangular controls.

## Components

### Primary Affiliate CTA Buttons
- **Style**: Solid `#00C853` with crisp `#0B192C` bold text (or `#FFFFFF` against `#046A38` variant). 
- **States**: Hover switches to `#046A38` with `#FFFFFF` text and a discrete transform of `translateY(-1px)`.
- **Additions**: Always accompanied by an external arrow indicator (`↗`) and micro-disclaimer ("Visit Official Site").

### Software Comparison Tables
- **Structure**: Sticky left column for tool branding/logo, fixed headers with dark navy backgrounds (`#0B192C`) or high-contrast white with strong bottom borders.
- **Zebra Striping**: Alternating row backgrounds between `#FFFFFF` and `#F8FAFC`.
- **Cell Alignment**: Strict vertical centering with green check icons (`#00C853`) and subdued slate crosses (`#60687A`).

### Rating Badges
- **Editorial Score Pill**: Pill container featuring `#0B192C` background, `#FFFFFF` score text, and a `#F59E0B` star icon.
- **Rank Indicator**: Positioned at the top-left of winner cards (e.g., "#1 Best Overall Dropshipping Tool") with an emerald outline and tint.

### Affiliate Disclosure Cards
- **Style**: Contained box rendered in `#F8FAFC` with a left-accent border (3px solid `#1E3E62`).
- **Typography**: `body-sm` in `#60687A` explaining advertiser relationship and editorial integrity transparently.

### Category Filter Tabs
- **Default**: Inactive tabs use transparent backgrounds, `#60687A` text, and subtle 1px border.
- **Active**: Filled `#0B192C` with crisp white text or underlined with a 2px `#00C853` bar.

### Review Feature Checkmarks
- **List items**: Custom circular green check icons (`18px`) containing white check vectors, paired with semi-bold feature highlights and standard body descriptive text.

### Form Inputs & Keyword Search Fields
- Crisp 1px `#CBD5E1` borders on `#FFFFFF` surfaces, expanding to an active focus ring (`2px solid #00C853` with 2px offset).